import Home from './Home'
import Register from './Register'

export {
    Home,
    Register
}
# API

blah blah

## Install

```sh
$ npm i
```

## Run

```sh
$ npm run start
```

### Inspect

```sh
$ npm run inspect
```

### Watch

```sh
$ npm run watch
```
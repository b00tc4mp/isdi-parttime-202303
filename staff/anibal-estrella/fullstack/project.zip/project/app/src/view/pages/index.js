import Home from './Home'
import Login from './Login'
import Profile from './Profile'

export {
    Home,
    Login,
    Profile
}